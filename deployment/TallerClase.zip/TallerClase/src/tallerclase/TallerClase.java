
package tallerclase;

import javax.swing.JOptionPane;


public class TallerClase {

    
    public static void main(String[] args) {
        LS listaC = new LS();
        int opc = 0;
        Estudiante e;
        Empleado em;
        
        do{
        
            opc = Integer.parseInt(JOptionPane.showInputDialog("Seleccione una de las siguientes opciones: \n1. Registrar \n2. Imprimir \n3. Buscar \n5. Salir "));
            switch(opc){
                case 1: 
                      String opt =  JOptionPane.showInputDialog("\n1. Estudiante \n2. Empleado.");
                      String opt2 =  JOptionPane.showInputDialog("\n1. Ordenar Atras  \n2. Ordenar Adelante.");
                           
                          if(opt.equals("1")){
                              String cod = JOptionPane.showInputDialog("Ingrese codigo de estudiante");
                              String name = JOptionPane.showInputDialog("Ingrese su nombre");
                              int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad"));
                              Double nota  = Double.parseDouble(JOptionPane.showInputDialog("Ingrese años de antiguedad"));
                              e = new Estudiante(cod, name, edad, nota);
                              listaC.InsertarNodo(e);
                          }
                          else if(opt.equals("2")){
                              String cod = JOptionPane.showInputDialog("Ingrese codigo de Empleado");
                              String name = JOptionPane.showInputDialog("Ingrese su nombre");
                              int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad"));
                              int aniosA  = Integer.parseInt(JOptionPane.showInputDialog("Ingrese años de antiguedad"));
                              double salario  = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el Salario: "));
                              em = new Empleado(cod, name, edad, aniosA, salario);
                              listaC.InsertarNodoEmpI(em);
                          }
                          break;
                                   
                case 2: 
                    
                    listaC.mostrarNodo();
              
                    
                    break;
                case 3: 
                    
                  //String cb = JOptionPane.showInputDialog("Ingrese el codigo a Buscar");
                  //JOptionPane.showMessageDialog(null, listaC(cb));
                    break;
                case 4: 
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opcion no valida");
                
            }
   
        }while(opc != 5);
    }
    
}
