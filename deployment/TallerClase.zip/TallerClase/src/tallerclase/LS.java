
package tallerclase;

import javax.swing.JOptionPane;


class LS {
    Nodo cabeza;
    NodoEmp head;
   int tamanio;
   
   // validar lista 
   
    public boolean ValidarLista() {
        return cabeza == null;
    }
     // validar lista 
   
    public boolean ValidarLista2() {
        return head == null;
    }
   //metodo insertar estudiante
     public void InsertarNodo(Estudiante e){
        
        /*1. */Nodo nuevo = new Nodo(e); 
        /*2. */if(ValidarLista()){
            cabeza = nuevo;
        }else{
            nuevo.setEnlace(cabeza);
            cabeza = nuevo;
        }            
        JOptionPane.showMessageDialog(null, "Estudiante Insertado ");
        
    }
      //metodo insertar Empleado inicio
     
     public void InsertarNodoEmpI(Empleado em){
        
        /*1. */NodoEmp nuevo = new NodoEmp(em); 
        /*2. */if(ValidarLista()){
            head = nuevo;
        }else{
            nuevo.setEnlace(head);
            head = nuevo;
        }           
        JOptionPane.showMessageDialog(null, "Empleado Insertado ");
        
    }
     // Metodo Insertar Empleado Final Final
     
     public void InsertarNodoEmpF(Empleado em){
        NodoEmp nuevo = new NodoEmp(em),p = head;
        if(ValidarLista()){
            head = nuevo;
        }else{
            while (p != null) {
                p = p.getEnlace();
            }
            p.setEnlace(nuevo);
        }        
     }
      // Metodo Insertar Estudiante Final Final
     
     public void InsertarNodoEstF(Estudiante e){
        Nodo nuevo = new Nodo(e),p = cabeza;
        if(ValidarLista()){
            cabeza = nuevo;
        }else{
            while (p != null) {
                p = p.getEnlace();
            }
            p.setEnlace(nuevo);
        }        
     }
     // Metodo para mostrar Empleado 
     
     public void mostrarNodo(){
        String salida="";
        NodoEmp p = head;
        if(p==null){
            JOptionPane.showMessageDialog(null, "La lista esta vacia!!");
        }else{
            while(p!=null){
                salida=salida+p.getem()+"  ";
                p=p.getEnlace();
            }
            JOptionPane.showMessageDialog(null, "Datos de la lista\n"+salida);
        }
    }
}
