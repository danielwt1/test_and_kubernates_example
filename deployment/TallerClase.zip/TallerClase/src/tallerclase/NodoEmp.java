
package tallerclase;


public class NodoEmp {
    
        private Empleado em;


    public NodoEmp(Empleado em, NodoEmp enlace) {
        this.em = em;
        this.enlace = enlace;
    }
    private NodoEmp enlace;

    NodoEmp(Empleado em) {
        
    }

    public Empleado getem() {
        return em;
    }

    public void setem(Empleado em) {
        this.em = em;
    }

    public NodoEmp getEnlace() {
        return enlace;
    }

    public void setEnlace(NodoEmp enlace) {
        this.enlace = enlace;
    } 


}
