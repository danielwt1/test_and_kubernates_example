
package tallerclase;


public class Empleado {
    private String codigo;
    private String nombre;
    private int edad;
    private int anosAnt;
    private double salario;

    public Empleado(String codigo, String nombre, int edad, int anosAnt, double salario) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.edad = edad;
        this.anosAnt = anosAnt;
        this.salario = salario;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getAnosAnt() {
        return anosAnt;
    }

    public void setAnosAnt(int anosAnt) {
        this.anosAnt = anosAnt;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    
}
