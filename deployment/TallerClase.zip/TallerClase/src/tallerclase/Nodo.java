
package tallerclase;


public class Nodo {
       private Estudiante e;

    public Nodo(Estudiante e, Nodo enlace) {
        this.e = e;
        this.enlace = enlace;
    }
    private Nodo enlace;

    Nodo(Estudiante e) {
        
    }

    public Estudiante gete() {
        return e;
    }

    public void sete(Estudiante e) {
        this.e = e;
    }

    public Nodo getEnlace() {
        return enlace;
    }

    public void setEnlace(Nodo enlace) {
        this.enlace = enlace;
    } 
}
