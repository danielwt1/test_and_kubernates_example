package prjpoo;

public class Motocicleta  extends Vehiculo{
    private int gato;
    private boolean sliders;
    
    public Motocicleta(){
        
    }

    public Motocicleta(int gato, boolean sliders, String placa, String marca, String modelo, String cilindraje, int valor) {
        super(placa, marca, modelo, cilindraje, valor);
        this.gato = gato;
        this.sliders = sliders;
    }

    public int getGato() {
        return gato;
    }

    public void setGato(int gato) {
        this.gato = gato;
    }

    public boolean getSliders() {
        return sliders;
    }

    public void setSliders(boolean sliders) {
        this.sliders = sliders;
    }
    
    
}
