
package prjpoo;

public class Vehiculo {
    //  Definir los atributos
    private String placa;
    private String marca;
    private String modelo;
    private String cilindraje;
    private int valor;
    // Métodos constructores
    public Vehiculo() {
    }

    public Vehiculo(String placa, String marca, String modelo, String cilindraje, int valor) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.cilindraje = cilindraje;
        this.valor = valor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
       this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(String cilindraje) {
        this.cilindraje = cilindraje;
    }
    
    public int getValor (){
        return this.valor;
    }
    
    public void setValor(int valor){
        this.valor = valor;
    }
    
    public void comprar (String placa, int valor){
        if (valor <= 100000000){
            System.out.println("Se ha comprado el vehículo con placa "+placa+" con un valor de "+valor);
        }
        else{
            System.out.println("Este vehiculo tiene un costo muy alto. No se puede comprar ....");
        }
    }
    
    public void vender(String placa, int valor){
        float miva = calcularIva(placa, valor);
        System.out.println("Placa  "+placa+",  valor "+valor+" valor iva "+miva);
    }
    
    private float calcularIva (String placa, int valor){
        return valor * 19/100;
    }
}
