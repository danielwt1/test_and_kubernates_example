
package prjpoo;

public class Camioneta  extends Vehiculo{
    private int capCarga;
    private boolean volco;
    
    public Camioneta(){
        
    }

    public Camioneta(int capCarga, boolean volco, String placa, String marca, String modelo, String cilindraje, int valor) {
        super(placa, marca, modelo, cilindraje, valor);
        this.capCarga = capCarga;
        this.volco = volco;
    }

    public int getCapCarga() {
        return capCarga;
    }

    public void setCapCarga(int capCarga) {
        this.capCarga = capCarga;
    }

    public boolean getVolco() {
        return volco;
    }

    public void setVolco(boolean volco) {
        this.volco = volco;
    }
    
    public void montarRemolque(String placa){
        System.out.println("Al vehiculo con placa "+placa+" se le ha montado un remolque ...");
    }
    
    
    
    
    
}
