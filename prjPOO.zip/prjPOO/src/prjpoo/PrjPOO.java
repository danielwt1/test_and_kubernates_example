package prjpoo;

public class PrjPOO {

    public static void main(String[] args) {
            // Aquí se definen los objetos de cada una de las clases.
            //Automovil auto1 = new Automovil();
            Automovil auto1 = new Automovil(3,"ghj345","Peugeot","2021","1400",350000000);
            System.out.println("La placa del automovil es: "+auto1.getPlaca());
            auto1.setValor(95000000);
            auto1.comprar(auto1.getPlaca(), auto1.getValor());
            auto1.vender(auto1.getPlaca(),auto1.getValor());
            System.out.println("El automovil con placa "+auto1.getPlaca()+ " está en "+auto1.aplicarVidriosPolar(auto1.getPlaca()));
            
            
        
            
            
            
            
            
            
            
            
    }
    
}
