package prjpoo;
public class Automovil extends Vehiculo {
    private int nropuertas;
    
    // no tiene atributos
    public Automovil() {
    }

    public Automovil(int nropuertas, String placa, String marca, String modelo, String cilindraje, int valor) {
        super(placa, marca, modelo, cilindraje, valor);
        this.nropuertas = nropuertas;
    }

    public int getNropuertas() {
        return nropuertas;
    }

    public void setNropuertas(int nropuertas) {
        this.nropuertas = nropuertas;
    }
    
    public boolean aplicarVidriosPolar(String placa){
        return true;
    }
    
    
    
    

    
    
    
    
    
    

    
    
    

    
}
